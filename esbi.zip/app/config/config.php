<?php
define('BASEURL', 'http://localhost/esbi/public');

// Database
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'esbi');

// define('BASEURL', 'https://abellnet.my.id/esbi/public');

// // Database
// define('DB_HOST', 'localhost');
// define('DB_USERNAME', 'abem9446_resa_endrawan');
// define('DB_PASSWORD', 'resa_endrawan');
// define('DB_NAME', 'abem9446_esbi');